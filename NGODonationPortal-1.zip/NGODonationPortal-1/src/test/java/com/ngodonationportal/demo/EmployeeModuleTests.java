package com.ngodonationportal.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ngodonationportal.dao.EmployeeDao;
import com.ngodonationportal.dao.NeedyPeopleDao;
import com.ngodonationportal.entity.Address;
import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.entity.NeedyPeople;
import com.ngodonationportal.service.EmployeeService;

/**
 * The Class EmployeeModuleTests.
 */
@SpringBootTest
class EmployeeModuleTests {

	/** The dao. */
	@MockBean
	NeedyPeopleDao dao;

	/** The dao 1. */
	@MockBean
	EmployeeDao dao1;

	/** The service. */
	@Autowired
	EmployeeService service;

	/**
	 * Test add needy person.
	 */
	@Test
	void testAddNeedyPerson() {
		NeedyPeople person = new NeedyPeople(123, "suresh", 1000000L, 25000);
		Mockito.when(dao.save(person)).thenReturn(person);
		NeedyPeople pr = service.addNeedyPerson(person);
		assertEquals("suresh", pr.getNeedyPersonName());
	}

	/**
	 * Test remove needy person.
	 */
	@Test
	void testRemoveNeedyPerson() {

		NeedyPeople person = new NeedyPeople(120, "Bunny", 9898989898L, 25000);
		service.removeNeedyPerson(120);
		Mockito.verify(dao, times(1)).deleteById(person.getNeedyPersonId());
		// assertEquals(needyPerson, "Deleted Successfully");
	}

	/**
	 * Test find needy people by id.
	 */
	@Test
	void testFindNeedyPeopleById() {
		Optional<NeedyPeople> person = Optional.of(new NeedyPeople(501, "Bunny", 1000000L, 25000));
		Mockito.when(dao.findById(501)).thenReturn(person);
		Optional<NeedyPeople> needyPeople = service.findNeedyPeopleById(501);
		assertEquals(person, needyPeople);
	}

	/**
	 * Test find needy people by name.
	 */
	@Test
	void testFindNeedyPeopleByName() {
		Optional<NeedyPeople> person = Optional.of(new NeedyPeople(501, "Bunty", 9797979797L, 35000));
		Mockito.when(dao.findByNeedyPeopleName("Bunty")).thenReturn(person);
		Optional<NeedyPeople> list = service.findNeedyPeopleByName("Bunty");
		assertEquals(person, list);
	}

	/**
	 * Test find all needy people.
	 */
	@Test
	void testFindAllNeedyPeople() {
		List<NeedyPeople> list = new ArrayList<NeedyPeople>();
		NeedyPeople person1 = new NeedyPeople(201, "Sunny", 5555599999L, 25000);
		NeedyPeople person2 = new NeedyPeople(202, "Bunny", 7777788888L, 25000);
		Mockito.when(dao.findAll()).thenReturn((Arrays.asList(person1, person2)));
		list = service.findAllNeedyPeople();
		assertEquals(2, list.size());

	}

	/**
	 * Test login.
	 */
	@Test
	void testLogin() {
		Address address = new Address(1254, "kurnool", "a.p", "518002", "Nandyal check");
		Employee employee = new Employee(123, "suresh", "gmail.com", 9011000L, address, "suri", "@123");
		Mockito.when(dao1.findByUsernameAndPassword("surya", "@123")).thenReturn(employee);
		Employee pr = service.login("surya", "@123");
		assertEquals(123, pr.getEmployeeId());
	}
}
