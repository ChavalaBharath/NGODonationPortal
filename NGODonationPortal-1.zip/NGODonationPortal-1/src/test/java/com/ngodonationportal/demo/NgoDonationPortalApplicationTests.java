package com.ngodonationportal.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ngodonationportal.dao.DonationDao;
import com.ngodonationportal.dao.DonorDao;
import com.ngodonationportal.entity.Address;
import com.ngodonationportal.entity.Donation;
import com.ngodonationportal.entity.DonationItem;
import com.ngodonationportal.entity.Donor;
import com.ngodonationportal.service.DonorService;

/**
 * The Class NgoDonationPortalApplicationTests.
 */
@SpringBootTest
class NgoDonationPortalApplicationTests {

	/** The dao 1. */
	@MockBean
	DonationDao dao1;

	/** The dao. */
	@MockBean
	DonorDao dao;

	/** The service. */
	@Autowired
	DonorService service;

	/**
	 * Test register donor.
	 */
	@Test
	void testRegisterDonor() {
		Address address = new Address(125, "hyd", "Tn", "518002", "landmark");
		Donor donor = new Donor(123, "suresh", "suresh@gmail.com", "8500251905", "Suresh", "Suresh@123", address);
		Mockito.when(dao.save(donor)).thenReturn(donor);
		Donor donor1 = service.registerDonor(donor);
		assertEquals("suresh", donor1.getDonorName());
	}

	/**
	 * Test reset password.
	 */
	@Test
	void testResetPassword() {
		Address address = new Address(125, "hyd", "Tn", "518002", "landmark");
		Optional<Donor> donor = Optional
				.of(new Donor(123, "suresh", "suresh@gmail.com", "8500251905", "Suresh", "Suresh@123", address));
		Mockito.when(dao.findById(123)).thenReturn(donor);
		Mockito.when(dao.save(donor.get())).thenReturn(donor.get());
		String donor2 = service.resetPassword(123, "Suresh@123", "Bharath@123");
		assertEquals("Bharath@123", donor2);
	}

	/**
	 * Test login.
	 */
	@Test
	void testLogin() {
		Address address = new Address(125, "hyd", "Tn", "518002", "landmark");
		Donor donor = new Donor(123, "suresh", "suresh@gmail.com", "8500251905", "Suresh", "Suresh@123", address);
		Mockito.when(dao.findByDonorUsernameAndPassword("Suresh", "Suresh@123")).thenReturn(donor);
		Donor donor2 = service.login("Suresh", "Suresh@123");
		assertEquals(123, donor2.getDonorId());
	}

	/**
	 * Test find donor by id.
	 */
	@Test
	void testFindDonorById() {
		Address address = new Address(125, "hyd", "Tn", "518002", "landmark");
		Optional<Donor> donor = Optional
				.of(new Donor(123, "suresh", "suresh@gmail.com", "8500251905", "Suresh", "Suresh@123", address));
		Mockito.when(dao.findById(123)).thenReturn(donor);
		Optional<Donor> donor1 = service.findDonorById(123);
		assertEquals(donor, donor1);
	}
	@Test
	void testDonateToNGO() {
		Date d1 = new Date(1998, 02, 14);
		Address address = new Address(125, "hyd", "Tn", "518002", "landmark");
		Donor donor = new Donor(123, "suresh", "suresh@gmail.com", "8500251905", "Suresh", "Suresh@123", address);
		DonationItem donationItem = new DonationItem(153, "Cloths 4pairs", null);
		Donation donation1 = new Donation(123, donor, 2522.50, d1, donationItem);
		Mockito.when(dao1.save(donation1)).thenReturn(donation1);
		Donation donation = service.donateToNGO(donation1);
		assertEquals(123, donation.getDonationId());
	}

}