package com.ngodonationportal.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ngodonationportal.dao.AdminDao;
import com.ngodonationportal.entity.Address;
import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.service.AdminService;

/**
 * The Class AdminModuleTests.
 */
@SpringBootTest
class AdminModuleTests {

	/** The dao. */
	@MockBean
	AdminDao dao;

	/** The service. */
	@Autowired
	AdminService service;

	/**
	 * Test add employee.
	 */
	@Test
	void testAddEmployee() {
		Address address = new Address(1, "hyd", "telagana", "51822", "kphb");
		Employee employee = new Employee(1, "madhu", "madhu@gmail.com", 952733911, address, "madhu", "9010");

		Mockito.when(dao.save(employee)).thenReturn(employee);

		Employee emp = service.addEmployee(employee);
		assertEquals("madhu", emp.getEmployeeName());
	}

	/**
	 * Test update employee.
	 */
	@Test
	void testUpdateEmployee() {
		Address address = new Address(1, "mum", "telagana", "51826", "kp");
		Employee employee = new Employee(1, "krishna", "krishna@gmail.com", 852733911, address, "madhu", "9010");
		Mockito.when(dao.save(employee)).thenReturn(employee);
		Employee emp = service.modifyEmployee(employee);
		assertEquals("krishna", emp.getEmployeeName());
	}

	/**
	 * Test find employee.
	 */
	@Test
	void testFindEmployee() {
		Address address = new Address(1, "hyd", "telagana", "51822", "kp");
		Optional<Employee> employee = Optional
				.of(new Employee(100, "krishna", "krishna@gmail.com", 852733911L, address, "madhu", "9010"));
		Mockito.when(dao.findById(100)).thenReturn((employee));
		Optional<Employee> emp = service.findEmployeeById(100);
		assertEquals(emp, employee);// assertEquals()
	}

	/**
	 * Test remove employee.
	 */
	@Test
	void testRemoveEmployee() {
		Address address = new Address(1, "hyd", "telagana", "51822", "kphb");
		Employee employee = new Employee(1, "krishna", "krishna@gmail.com", 852733911, address, "madhu", "9010");
		service.removeEmployee(employee.getEmployeeId());
		Mockito.verify(dao, times(1)).deleteById(1);
	}

	/**
	 * Test find all employees.
	 */
	@Test
	void testFindAllEmployees() {
		List<Employee> list = new ArrayList<Employee>();
		Address address = new Address(1, "hyd", "telagana", "51822", "kphb");
		Address address1 = new Address(2, "hyd", "telagana", "51822", "kphb");
		Employee employee1 = new Employee(1, "krishna", "krishna@gmail.com", 852733911, address, "madhu", "9010");
		Employee employee2 = new Employee(2, "madhu", "madhu@gmail.com", 952733911, address1, "madhu", "9010");
		Mockito.when(dao.findAll()).thenReturn((Arrays.asList(employee1, employee2)));
		list = service.findAllEmployees();
		assertEquals(2, list.size());

	}
}