package com.ngodonationportal.exceptions;

/**
 * The Class RecordNotFoundException.
 */
public class RecordNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new record not found exception.
	 *
	 * @param message the message
	 */
	public RecordNotFoundException(String message) {
		super(message);
	}

}
