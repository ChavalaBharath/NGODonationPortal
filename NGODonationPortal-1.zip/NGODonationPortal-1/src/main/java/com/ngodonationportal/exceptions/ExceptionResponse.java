package com.ngodonationportal.exceptions;

import java.time.LocalDateTime;

/**
 * The Class ExceptionResponse.
 */
public class ExceptionResponse {

	/** The status. */
	private int status;

	/** The message. */
	private String message;

	/** The time. */
	private LocalDateTime time;

	/**
	 * Instantiates a new exception response.
	 */
	public ExceptionResponse() {
		super();
	}

	/**
	 * Instantiates a new exception response.
	 *
	 * @param status  the status
	 * @param message the message
	 * @param time    the time
	 */
	public ExceptionResponse(int status, String message, LocalDateTime time) {
		super();
		this.status = status;
		this.message = message;
		this.time = time;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * Gets the message.
	 *
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Gets the time.
	 *
	 * @return the time
	 */
	public LocalDateTime getTime() {
		return time;
	}

	/**
	 * Sets the time.
	 *
	 * @param time the new time
	 */
	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "ExceptionResponse [status=" + status + ", message=" + message + ", time=" + time + "]";
	}

}
