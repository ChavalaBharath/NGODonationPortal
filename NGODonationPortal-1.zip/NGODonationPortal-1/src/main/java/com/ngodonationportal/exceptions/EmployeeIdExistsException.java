package com.ngodonationportal.exceptions;

/**
 * The Class EmployeeIdExistsException.
 */
public class EmployeeIdExistsException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new employee id exists exception.
	 *
	 * @param message the message
	 */
	public EmployeeIdExistsException(String message) {
		super(message);

	}

}
