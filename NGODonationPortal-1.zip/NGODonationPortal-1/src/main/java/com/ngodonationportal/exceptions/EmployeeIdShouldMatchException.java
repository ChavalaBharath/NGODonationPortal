package com.ngodonationportal.exceptions;

/**
 * The Class EmployeeIdShouldMatchException.
 */
public class EmployeeIdShouldMatchException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new employee id should match exception.
	 *
	 * @param message the message
	 */
	public EmployeeIdShouldMatchException(String message) {

		super(message);

	}

}
