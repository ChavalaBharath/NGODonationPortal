package com.ngodonationportal.exceptions;

/**
 * The Class EmployeeIdNotFoundException.
 */
public class EmployeeIdNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new employee id not found exception.
	 *
	 * @param message the message
	 */
	public EmployeeIdNotFoundException(String message) {

		super(message);
	}

}
