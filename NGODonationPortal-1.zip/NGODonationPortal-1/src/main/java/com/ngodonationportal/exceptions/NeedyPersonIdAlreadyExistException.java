package com.ngodonationportal.exceptions;

/**
 * The Class NeedyPersonIdAlreadyExistException.
 */
public class NeedyPersonIdAlreadyExistException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new needy person id already exist exception.
	 *
	 * @param message the message
	 */
	public NeedyPersonIdAlreadyExistException(String message) {
		super(message);
	}

}
