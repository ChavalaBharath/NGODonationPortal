package com.ngodonationportal.exceptions;

/**
 * The Class DonorDoesntExistException.
 */
public class DonorDoesntExistException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new donor doesnt exist exception.
	 *
	 * @param message the message
	 */
	public DonorDoesntExistException(String message) {
		super(message);
	}

}
