package com.ngodonationportal.exceptions;

/**
 * The Class EmployeeIdMustBeValidToDeleteException.
 */
public class EmployeeIdMustBeValidToDeleteException extends Exception {

	
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new employee id must be valid to delete exception.
	 *
	 * @param message the message
	 */
	public EmployeeIdMustBeValidToDeleteException(String message) {
		super(message);
	}

}
