package com.ngodonationportal.exceptions;

/**
 * The Class DonorExistException.
 */
public class DonorExistException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new donor exist exception.
	 *
	 * @param message the message
	 */
	public DonorExistException(String message) {
		super(message);
	}

}
