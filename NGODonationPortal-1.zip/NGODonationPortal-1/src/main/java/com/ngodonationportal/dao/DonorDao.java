package com.ngodonationportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ngodonationportal.entity.Donor;


/**
 * The Interface DonorDao.
 */
@Repository
public interface DonorDao extends JpaRepository<Donor, Integer>{
	
	/**
	 * Find by donor email.
	 *
	 * @param donorEmail the donor email
	 * @return the donor
	 */
	@Query("select e from Donor e where e.donorEmail = ?1")
    public Donor findByDonorEmail(String donorEmail);
	
	/**
	 * Find by donor username and password.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the donor
	 */
	@Query("select e from Donor e where e.donorUsername = ?1 and e.donorPassword = ?2")
    public Donor findByDonorUsernameAndPassword(String username,String password);
 
}
