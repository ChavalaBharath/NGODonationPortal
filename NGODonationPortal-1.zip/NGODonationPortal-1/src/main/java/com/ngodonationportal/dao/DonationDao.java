package com.ngodonationportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ngodonationportal.entity.Donation;

/**
 * The Interface DonationDao.
 */
public interface DonationDao extends JpaRepository<Donation, Integer>{

}
