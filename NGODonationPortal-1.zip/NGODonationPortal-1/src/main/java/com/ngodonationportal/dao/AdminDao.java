package com.ngodonationportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ngodonationportal.entity.Employee;

/**
 * The Interface AdminDao.
 */
@Repository
public interface AdminDao extends JpaRepository<Employee, Integer> {

}
