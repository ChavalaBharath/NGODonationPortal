package com.ngodonationportal.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ngodonationportal.entity.Employee;

/**
 * The Interface EmployeeDao.
 */
public interface EmployeeDao extends JpaRepository<Employee, Integer> {

	/**
	 * Find by username and password.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the employee
	 */
	@Query("select e from Employee e where e.username = ?1 and e.password = ?2")
	public Employee findByUsernameAndPassword(String username, String password);

}
