package com.ngodonationportal.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ngodonationportal.entity.NeedyPeople;

/**
 * The Interface NeedyPeopleDao.
 */
@Repository
public interface NeedyPeopleDao extends JpaRepository<NeedyPeople, Integer> {

	/**
	 * Find by needy people name.
	 *
	 * @param name the name
	 * @return the optional
	 */
	@Query("select e from NeedyPeople e where e.needyPersonName = ?1")
	public Optional<NeedyPeople> findByNeedyPeopleName(String name);

}
