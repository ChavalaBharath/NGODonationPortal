package com.ngodonationportal.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ngodonationportal.entity.Donor;
import com.ngodonationportal.exceptions.DonorDoesntExistException;
import com.ngodonationportal.exceptions.DonorExistException;
import com.ngodonationportal.service.DonorService;

/**
 * The Class DonationController.
 */
@RestController
@RequestMapping("/donation")
public class DonationController {

	/** The service. */
	@Autowired
	DonorService service;

	/**
	 * Register donor.
	 *
	 * @param donor the donor
	 * @return the donor
	 * @throws DonorExistException the donor exist exception
	 */
	@PostMapping("/registerDonor")//http://localhost:2010/donation/registerDonor
	public Donor registerDonor(@RequestBody Donor donor) throws DonorExistException {

		Optional<Donor> donor1 = service.findDonorById(donor.getDonorId());
		if (donor1.isPresent()) {
			throw new DonorExistException("User already exists");
		} else {
			return service.registerDonor(donor);
		}
	}

	/**
	 * Reset password.
	 *
	 * @param donorId     the donor id
	 * @param oldPassword the old password
	 * @param newPassword the new password
	 * @return the string
	 */
	@PutMapping("/resetPassword/{donorId}/{oldPassword}/{newPassword}")//http://localhost:2010/donation/resetPassword/{donorId}/{oldPassword}/{newPassword}
	public String resetPassword(@PathVariable("donorId") int donorId, @PathVariable("oldPassword") String oldPassword,
			@PathVariable("newPassword") String newPassword) {
		return service.resetPassword(donorId, oldPassword, newPassword);
	}

	/**
	 * Email password to donor.
	 *
	 * @param donorEmail the donor email
	 * @return the string
	 * @throws DonorDoesntExistException the donor doesnt exist exception
	 */
	@GetMapping("/emailPasswordToDonor/{donorEmail}")//http://localhost:2010/donation/emailPasswordToDonor/{donorEmail}
	public String emailPasswordToDonor(@PathVariable("donorEmail") String donorEmail) throws DonorDoesntExistException {
		String donor1 = service.emailPasswordToDonor(donorEmail);
		if (donor1 != (null)) {
			return donor1;

		} else {
			throw new DonorDoesntExistException("Invalid email");
		}
	}

	/**
	 * Login.
	 *
	 * @param donorUsername the donor username
	 * @param donorPassword the donor password
	 * @return the donor
	 */
	@GetMapping("/login/{donor_Username}/{donor_Password}")//http://localhost:2010/donation/login/{donor_Username}/{donor_Password}
	public Donor login(@PathVariable("donor_Username") String donorUsername,
			@PathVariable("donor_Password") String donorPassword) throws DonorDoesntExistException {
		Donor donor = service.login(donorUsername, donorPassword);
		if (donor != (null)) {
			return donor;

		} else {
			throw new DonorDoesntExistException("Incorrect Details");
		}

	}

	/**
	 * Forgot password.
	 *
	 * @param donorId the donor id
	 * @return the string
	 * @throws DonorDoesntExistException the donor doesnt exist exception
	 */
	@GetMapping("/forgotPassword/{donor_Id}")//http://localhost:2010/donation/forgotPassword/{donor_Id}
	public String forgotPassword(@PathVariable("donor_Id") int donorId) throws DonorDoesntExistException {
		Optional<Donor> donor1 = service.findDonorById(donorId);
		if (donor1.isPresent()) {
			return service.forgotPassword(donorId);

		} else {
			throw new DonorDoesntExistException("Incorrect UserId");
		}
	}

	/**
	 * Find donor by id.
	 *
	 * @param donorId the donor id
	 * @return the optional
	 * @throws DonorDoesntExistException the donor doesnt exist exception
	 */
	@GetMapping("/findDonorById/{donor_Id}")//http://localhost:2010/donation/findDonorById/{donor_Id}
	public Optional<Donor> findDonorById(@PathVariable("donor_Id") int donorId) throws DonorDoesntExistException {
		Optional<Donor> donor1 = service.findDonorById(donorId);
		if (donor1.isPresent()) {
			return service.findDonorById(donorId);

		} else {
			throw new DonorDoesntExistException("Enter the Correct UserId");
		}
	}

}
