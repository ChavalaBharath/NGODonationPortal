package com.ngodonationportal.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.entity.NeedyPeople;
import com.ngodonationportal.exceptions.NeedyPersonIdAlreadyExistException;
import com.ngodonationportal.exceptions.RecordNotFoundException;
import com.ngodonationportal.service.EmployeeService;

/**
 * The Class EmployeeController.
 */
@RestController
@RequestMapping("/employee") // http://localhost:2017/employee/addNeedyPerson
public class EmployeeController {

	/** The service. */
	@Autowired
	private EmployeeService service;

	/**
	 * Adds the needy person.
	 *
	 * @param person the person
	 * @return the needy people
	 * @throws NeedyPersonIdAlreadyExistException the needy person id already exist
	 *                                            exception
	 */
	@PostMapping("/addNeedyPerson")
	public NeedyPeople addNeedyPerson(@Valid @RequestBody NeedyPeople person)
			throws NeedyPersonIdAlreadyExistException {
		Optional<NeedyPeople> np1 = service.findNeedyPeopleById(person.getNeedyPersonId());
		if (np1.isPresent()) {
			throw new NeedyPersonIdAlreadyExistException("A Person is already present with given ID use a New Id");
		} else {
			return service.addNeedyPerson(person);
		}

	}

	/**
	 * Removes the needy person.
	 *
	 * @param needyPersonId the needy person id
	 * @return the string
	 * @throws RecordNotFoundException the record not found exception
	 */
	@DeleteMapping("/deleteNeedyPerson/{Id}")
	public String removeNeedyPerson(@PathVariable("Id") int needyPersonId) throws RecordNotFoundException {
		Optional<NeedyPeople> needy = service.findNeedyPeopleById(needyPersonId);
		if (needy.isPresent()) {
			return service.removeNeedyPerson(needyPersonId);
		} else {
			throw new RecordNotFoundException("Entered Id does not exist enter a valid Id");
		}
	}

	/**
	 * Find needy people by id.
	 *
	 * @param needyPersonId the needy person id
	 * @return the optional
	 * @throws RecordNotFoundException the record not found exception
	 */
	@GetMapping("/findNeedyPeopleById/{Id}")
	public Optional<NeedyPeople> findNeedyPeopleById(@Valid @PathVariable("Id") int needyPersonId)
			throws RecordNotFoundException {
		Optional<NeedyPeople> needy = service.findNeedyPeopleById(needyPersonId);
		if (needy.isPresent()) {
			return service.findNeedyPeopleById(needyPersonId);
		} else {
			throw new RecordNotFoundException("There is no person with Given Id enter a valid Id");
		}

	}

	/**
	 * Find needy people by name.
	 *
	 * @param name the name
	 * @return the optional
	 * @throws RecordNotFoundException the record not found exception
	 */
	@GetMapping("/findNeedyPeopleByName/{name}")
	public Optional<NeedyPeople> findNeedyPeopleByName(@Valid @PathVariable("name") String name)
			throws RecordNotFoundException {
		Optional<NeedyPeople> needyPeople = service.findNeedyPeopleByName(name);
		if (needyPeople.isPresent()) {
			return service.findNeedyPeopleByName(name);
		} else {
			throw new RecordNotFoundException("There is no NeedyPerson with given name");
		}
	}

	/**
	 * Find all needy people.
	 *
	 * @return the list
	 */
	@GetMapping("/findAllNeedyPeople")
	public List<NeedyPeople> findAllNeedyPeople() {

		return service.findAllNeedyPeople();

	}

	/**
	 * Login.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the employee
	 */
	@PostMapping("/login/{username}/{password}")
	public Employee login(@Valid @PathVariable("username") String username, @PathVariable("password") String password) {
		return service.login(username, password);
	}

}
