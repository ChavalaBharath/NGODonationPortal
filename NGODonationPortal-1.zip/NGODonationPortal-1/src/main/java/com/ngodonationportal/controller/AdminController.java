package com.ngodonationportal.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.exceptions.EmployeeIdExistsException;
import com.ngodonationportal.exceptions.EmployeeIdMustBeValidToDeleteException;
import com.ngodonationportal.exceptions.EmployeeIdNotFoundException;
import com.ngodonationportal.service.AdminService;

/**
 * The Class AdminController.
 */
@RestController
@RequestMapping("/admin")
public class AdminController {

	/** The service. */
	@Autowired
	AdminService service;

	/**
	 * Adds the employee.
	 *
	 * @param employee the employee
	 * @return the employee
	 * @throws EmployeeIdNotFoundException the employee id not found exception
	 */
	@PostMapping("/addEmployee")
	public Employee addEmployee(@RequestBody Employee employee) throws EmployeeIdNotFoundException {
		Optional<Employee> emp = service.findEmployeeById(employee.getEmployeeId());
		if (emp.isPresent()) {
			throw new EmployeeIdNotFoundException("id already exists");
		} else {
			return service.addEmployee(employee);
		}
	}

	/**
	 * Update employee.
	 *
	 * @param emp the emp
	 * @return the employee
	 * @throws EmployeeIdExistsException the employee id exists exception
	 */
	@PutMapping("/modifyEmployee")
	public Employee updateEmployee(@RequestBody Employee emp) throws EmployeeIdExistsException {
		Optional<Employee> emp1 = service.findEmployeeById(emp.getEmployeeId());
		if (emp1.isPresent()) {
			return service.modifyEmployee(emp);
		} else {
			throw new EmployeeIdExistsException("enter valid id to update details");
		}
	}

	/**
	 * Removes the employee.
	 *
	 * @param empId the emp id
	 * @return the string
	 * @throws EmployeeIdMustBeValidToDeleteException the employee id must be valid to delete exception
	 */
	@DeleteMapping("/removeEmployee/{empId}")
	public String removeEmployee(@PathVariable int empId) throws EmployeeIdMustBeValidToDeleteException {
		Optional<Employee> emp1 = service.findEmployeeById(empId);
		if (emp1.isPresent()) {
			return service.removeEmployee(empId);
		} else {
			throw new EmployeeIdMustBeValidToDeleteException("enter valid id to delete");
		}
	}

	/**
	 * Gets the employee.
	 *
	 * @param empId the emp id
	 * @return the employee
	 * @throws EmployeeIdNotFoundException the employee id not found exception
	 */
	@GetMapping("/getEmployee/{empId}")
	public Employee getEmployee(@PathVariable int empId) throws EmployeeIdNotFoundException {

		Optional<Employee> emp = service.findEmployeeById(empId);
		if (emp.isPresent()) {
			return emp.get();
		} else {
			throw new EmployeeIdNotFoundException("with the given id employee not found");
		}
	}

	/**
	 * Find employees.
	 *
	 * @return the list
	 */
	@GetMapping("/getAllEmployees")
	public List<Employee> findEmployees() {
		return service.findAllEmployees();
	}

}
