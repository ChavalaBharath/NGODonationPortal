package com.ngodonationportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

/**
 * The Class NeedyPeople.
 */
@Entity
@Table(name = "needy_people")
public class NeedyPeople {

	/** The needy person id. */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Positive
	@NotNull
	@Column(name = "needy_personId", length = 10)
	private int needyPersonId;

	/** The needy person name. */
	@NotNull
	@Column(name = "needy_personName", length = 20)
	private String needyPersonName;

	/** The phone number. */
	@NotNull
	@Column(name = "phone_number")
	private long phoneNumber;

	/** The family income. */
	@NotNull
	@Column(name = "famil_Income", length = 10)
	private double familyIncome;

	/** The address. */
	@JoinColumn(name = "id")
	@OneToOne
	private Address address;

	/**
	 * Instantiates a new needy people.
	 */
	public NeedyPeople() {
		super();
	}

	/**
	 * Instantiates a new needy people.
	 *
	 * @param needyPersonId   the needy person id
	 * @param needyPersonName the needy person name
	 * @param phoneNumber     the phone number
	 * @param familyIncome    the family income
	 */
	public NeedyPeople(int needyPersonId, String needyPersonName, long phoneNumber, double familyIncome) {
		super();
		this.needyPersonId = needyPersonId;
		this.needyPersonName = needyPersonName;
		this.phoneNumber = phoneNumber;
		this.familyIncome = familyIncome;
	}

	/**
	 * Gets the needy person id.
	 *
	 * @return the needy person id
	 */
	public int getNeedyPersonId() {
		return needyPersonId;
	}

	/**
	 * Sets the needy person id.
	 *
	 * @param needyPersonId the new needy person id
	 */
	public void setNeedyPersonId(int needyPersonId) {
		this.needyPersonId = needyPersonId;
	}

	/**
	 * Gets the needy person name.
	 *
	 * @return the needy person name
	 */
	public String getNeedyPersonName() {
		return needyPersonName;
	}

	/**
	 * Sets the needy person name.
	 *
	 * @param needyPersonName the new needy person name
	 */
	public void setNeedyPersonName(String needyPersonName) {
		this.needyPersonName = needyPersonName;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return the phone number
	 */
	public long getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber the new phone number
	 */
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Gets the family income.
	 *
	 * @return the family income
	 */
	public double getFamilyIncome() {
		return familyIncome;
	}

	/**
	 * Sets the family income.
	 *
	 * @param familyIncome the new family income
	 */
	public void setFamilyIncome(double familyIncome) {
		this.familyIncome = familyIncome;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "NeedyPeople [needyPersonId=" + needyPersonId + ", needyPersonName=" + needyPersonName + ", phoneNumber="
				+ phoneNumber + ", familyIncome=" + familyIncome + "]";
	}

}
