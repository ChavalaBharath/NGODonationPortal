package com.ngodonationportal.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The Class DonationDistribution.
 */
@Entity
@Table(name = "Donation_Distribution")
public class DonationDistribution {
	/** The distribution id. */
	@Id
	@GeneratedValue
	@Column(name = "distribution_Id", length = 10)
	private int distributionId;

	/** The amount distributed. */
	private double amountDistributed;

	/** The date of distribution. */
	@Column(name = "dateOfDistribution", length = 10)
	private Date dateOfDistribution;

	/** The approval or rejected date. */
	private Date approvalOrRejectedDate;

	/** The employee. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "c1")
	private Employee employee;

	/** The person. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "c2")
	private NeedyPeople person;

	/** The item. */
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "c3")
	private DonationItem item;

	/** The status. */
	private DonationDistributionStatus status;

	/**
	 * Instantiates a new donation distribution.
	 *
	 * @param distributionId         the distribution id
	 * @param amountDistributed      the amount distributed
	 * @param dateOfDistribution     the date of distribution
	 * @param approvalOrRejectedDate the approval or rejected date
	 * @param employee               the employee
	 * @param person                 the person
	 * @param item                   the item
	 * @param status                 the status
	 */
	public DonationDistribution(int distributionId, double amountDistributed, Date dateOfDistribution,
			Date approvalOrRejectedDate, Employee employee, NeedyPeople person, DonationItem item,
			DonationDistributionStatus status) {
		super();
		this.distributionId = distributionId;
		this.amountDistributed = amountDistributed;
		this.dateOfDistribution = dateOfDistribution;
		this.approvalOrRejectedDate = approvalOrRejectedDate;
		this.employee = employee;
		this.person = person;
		this.item = item;
		this.status = status;
	}

	/**
	 * Instantiates a new donation distribution.
	 */
	public DonationDistribution() {
		super();
	}

	/**
	 * Gets the distribution id.
	 *
	 * @return the distribution id
	 */
	public int getDistributionId() {
		return distributionId;
	}

	/**
	 * Sets the distribution id.
	 *
	 * @param distributionId the new distribution id
	 */
	public void setDistributionId(int distributionId) {
		this.distributionId = distributionId;
	}

	/**
	 * Gets the amount distributed.
	 *
	 * @return the amount distributed
	 */
	public double getAmountDistributed() {
		return amountDistributed;
	}

	/**
	 * Sets the amount distributed.
	 *
	 * @param amountDistributed the new amount distributed
	 */
	public void setAmountDistributed(double amountDistributed) {
		this.amountDistributed = amountDistributed;
	}

	/**
	 * Gets the date of distribution.
	 *
	 * @return the date of distribution
	 */
	public Date getDateOfDistribution() {
		return dateOfDistribution;
	}

	/**
	 * Sets the date of distribution.
	 *
	 * @param dateOfDistribution the new date of distribution
	 */
	public void setDateOfDistribution(Date dateOfDistribution) {
		this.dateOfDistribution = dateOfDistribution;
	}

	/**
	 * Gets the approval or rejected date.
	 *
	 * @return the approval or rejected date
	 */
	public Date getApprovalOrRejectedDate() {
		return approvalOrRejectedDate;
	}

	/**
	 * Sets the approval or rejected date.
	 *
	 * @param approvalOrRejectedDate the new approval or rejected date
	 */
	public void setApprovalOrRejectedDate(Date approvalOrRejectedDate) {
		this.approvalOrRejectedDate = approvalOrRejectedDate;
	}

	/**
	 * Gets the employee.
	 *
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * Sets the employee.
	 *
	 * @param employee the new employee
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * Gets the person.
	 *
	 * @return the person
	 */
	public NeedyPeople getPerson() {
		return person;
	}

	/**
	 * Sets the person.
	 *
	 * @param person the new person
	 */
	public void setPerson(NeedyPeople person) {
		this.person = person;
	}

	/**
	 * Gets the item.
	 *
	 * @return the item
	 */
	public DonationItem getItem() {
		return item;
	}

	/**
	 * Sets the item.
	 *
	 * @param item the new item
	 */
	public void setItem(DonationItem item) {
		this.item = item;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public DonationDistributionStatus getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(DonationDistributionStatus status) {
		this.status = status;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DonationDistribution [distributionId=" + distributionId + ", amountDistributed=" + amountDistributed
				+ ", dateOfDistribution=" + dateOfDistribution + ", approvalOrRejectedDate=" + approvalOrRejectedDate
				+ ", employee=" + employee + ", person=" + person + ", item=" + item + ", status=" + status + "]";
	}

}