package com.ngodonationportal.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 * The Class Donor.
 */
@Entity
public class Donor {

	/** The donor id. */
	@Id
	@Column(name = "donor_Id", length = 10)
	private int donorId;

	/** The donor name. */
	@Column(name = "donor_Name", length = 10)
	private String donorName;

	/** The donor email. */
	@Column(name = "donor_Email", length = 20)
	private String donorEmail;

	/** The donor phone. */
	@Column(name = "donor_Phone", length = 10)
	private String donorPhone;

	/** The donor username. */
	private String donorUsername;

	/** The donor password. */
	private String donorPassword;

	/** The address. */
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;

	/**
	 * Instantiates a new donor.
	 */
	public Donor() {
		super();

	}

	/**
	 * Instantiates a new donor.
	 *
	 * @param donorId       the donor id
	 * @param donorName     the donor name
	 * @param donorEmail    the donor email
	 * @param donorPhone    the donor phone
	 * @param donorUsername the donor username
	 * @param donorPassword the donor password
	 * @param address       the address
	 */
	public Donor(int donorId, String donorName, String donorEmail, String donorPhone, String donorUsername,
			String donorPassword, Address address) {
		super();
		this.donorId = donorId;
		this.donorName = donorName;
		this.donorEmail = donorEmail;
		this.donorPhone = donorPhone;
		this.donorUsername = donorUsername;
		this.donorPassword = donorPassword;
		this.address = address;
	}

	/**
	 * Gets the donor id.
	 *
	 * @return the donor id
	 */
	public int getDonorId() {
		return donorId;
	}

	/**
	 * Sets the donor id.
	 *
	 * @param donorId the new donor id
	 */
	public void setDonorId(int donorId) {
		this.donorId = donorId;
	}

	/**
	 * Gets the donor name.
	 *
	 * @return the donor name
	 */
	public String getDonorName() {
		return donorName;
	}

	/**
	 * Sets the donor name.
	 *
	 * @param donorName the new donor name
	 */
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}

	/**
	 * Gets the donor email.
	 *
	 * @return the donor email
	 */
	public String getDonorEmail() {
		return donorEmail;
	}

	/**
	 * Sets the donor email.
	 *
	 * @param donorEmail the new donor email
	 */
	public void setDonorEmail(String donorEmail) {
		this.donorEmail = donorEmail;
	}

	/**
	 * Gets the donor phone.
	 *
	 * @return the donor phone
	 */
	public String getDonorPhone() {
		return donorPhone;
	}

	/**
	 * Sets the donor phone.
	 *
	 * @param donorPhone the new donor phone
	 */
	public void setDonorPhone(String donorPhone) {
		this.donorPhone = donorPhone;
	}

	/**
	 * Gets the donor username.
	 *
	 * @return the donor username
	 */
	public String getDonorUsername() {
		return donorUsername;
	}

	/**
	 * Sets the donor username.
	 *
	 * @param donorUsername the new donor username
	 */
	public void setDonorUsername(String donorUsername) {
		this.donorUsername = donorUsername;
	}

	/**
	 * Gets the donor password.
	 *
	 * @return the donor password
	 */
	public String getDonorPassword() {
		return donorPassword;
	}

	/**
	 * Sets the donor password.
	 *
	 * @param donorPassword the new donor password
	 */
	public void setDonorPassword(String donorPassword) {
		this.donorPassword = donorPassword;
	}

	/**
	 * Gets the address.
	 *
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * Sets the address.
	 *
	 * @param address the new address
	 */
	public void setAddress(Address address) {
		this.address = address;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Donor [donorId=" + donorId + ", donorName=" + donorName + ", donorEmail=" + donorEmail + ", donorPhone="
				+ donorPhone + ", donorUsername=" + donorUsername + ", donorPassword=" + donorPassword + ", address="
				+ address + "]";
	}

}