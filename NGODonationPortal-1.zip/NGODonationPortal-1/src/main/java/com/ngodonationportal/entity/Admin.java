package com.ngodonationportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The Class Admin.
 */
@Entity
@Table(name = "Admindetails")
public class Admin {
	
	/** The admin id. */
	@Id
	@Column(name = "eid", length = 10)
	private int adminId;
	
	/** The admin username. */
	@Column(name = "ename", length = 1)
	@NotBlank(message = "madhu")
	@NotNull(message = "enter any value")
	@Size(min = 1, max = 10)
	private String adminUsername;
	
	/** The admin password. */
	private String adminPassword;

	/**
	 * Instantiates a new admin.
	 *
	 * @param adminId the admin id
	 * @param adminUsername the admin username
	 * @param adminPassword the admin password
	 */
	public Admin(int adminId, String adminUsername, String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminUsername = adminUsername;
		this.adminPassword = adminPassword;
	}

	/**
	 * Instantiates a new admin.
	 */
	public Admin() {
		super();
	}

	/**
	 * Gets the admin id.
	 *
	 * @return the admin id
	 */
	public int getAdminId() {
		return adminId;
	}

	/**
	 * Sets the admin id.
	 *
	 * @param adminId the new admin id
	 */
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	/**
	 * Gets the admin username.
	 *
	 * @return the admin username
	 */
	public String getAdminUsername() {
		return adminUsername;
	}

	/**
	 * Sets the admin username.
	 *
	 * @param adminUsername the new admin username
	 */
	public void setAdminUsername(String adminUsername) {
		this.adminUsername = adminUsername;
	}

	/**
	 * Gets the admin password.
	 *
	 * @return the admin password
	 */
	public String getAdminPassword() {
		return adminPassword;
	}

	/**
	 * Sets the admin password.
	 *
	 * @param adminPassword the new admin password
	 */
	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminUsername=" + adminUsername + ", adminPassword=" + adminPassword
				+ "]";
	}
	

}
