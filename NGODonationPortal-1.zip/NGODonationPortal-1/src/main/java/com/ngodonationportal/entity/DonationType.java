package com.ngodonationportal.entity;

/**
 * The Enum DonationType.
 */
public enum DonationType {

	/** The money. */
	MONEY,
	/** The cloths. */
	CLOTHS,
	/** The books. */
	BOOKS,
	/** The edible. */
	EDIBLE,
	/** The other. */
	OTHER

}
