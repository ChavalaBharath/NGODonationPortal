package com.ngodonationportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class DonationBox.
 */
@Entity
@Table(name = "DonationBox")
public class DonationBox {

	/** The ngo name. */
	@Id
	@GeneratedValue
	@Column(name = "ngo_Name", length = 10)
	private String ngoName;

	/** The registration number. */
	private String registrationNumber;

	/** The account number. */
	private String accountNumber;

	/** The total collection. */
	private double totalCollection;

	/**
	 * Instantiates a new donation box.
	 *
	 * @param ngoName            the ngo name
	 * @param registrationNumber the registration number
	 * @param accountNumber      the account number
	 * @param totalCollection    the total collection
	 */
	public DonationBox(String ngoName, String registrationNumber, String accountNumber, double totalCollection) {
		super();
		this.ngoName = ngoName;
		this.registrationNumber = registrationNumber;
		this.accountNumber = accountNumber;
		this.totalCollection = totalCollection;
	}

	/**
	 * Instantiates a new donation box.
	 */
	public DonationBox() {
		super();
	}

	/**
	 * Gets the ngo name.
	 *
	 * @return the ngo name
	 */
	public String getNgoName() {
		return ngoName;
	}

	/**
	 * Sets the ngo name.
	 *
	 * @param ngoName the new ngo name
	 */
	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	/**
	 * Gets the registration number.
	 *
	 * @return the registration number
	 */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	/**
	 * Sets the registration number.
	 *
	 * @param registrationNumber the new registration number
	 */
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	/**
	 * Gets the account number.
	 *
	 * @return the account number
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Sets the account number.
	 *
	 * @param accountNumber the new account number
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Gets the total collection.
	 *
	 * @return the total collection
	 */
	public double getTotalCollection() {
		return totalCollection;
	}

	/**
	 * Sets the total collection.
	 *
	 * @param totalCollection the new total collection
	 */
	public void setTotalCollection(double totalCollection) {
		this.totalCollection = totalCollection;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DonationBox [ngoName=" + ngoName + ", registrationNumber=" + registrationNumber + ", accountNumber="
				+ accountNumber + ", totalCollection=" + totalCollection + "]";
	}

}
