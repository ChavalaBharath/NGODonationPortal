package com.ngodonationportal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class DonationItem.
 */
@Entity
@Table(name = "DonationItem")
public class DonationItem {

	/** The item id. */
	@Id
	@GeneratedValue
	@Column(name = "item_Id", length = 10)
	private int itemId;

	/** The item description. */
	private String itemDescription;

	/** The item. */
	private DonationType item;

	/**
	 * Instantiates a new donation item.
	 */
	public DonationItem() {
		super();
	}

	/**
	 * Instantiates a new donation item.
	 *
	 * @param itemId          the item id
	 * @param itemDescription the item description
	 * @param item            the item
	 */
	public DonationItem(int itemId, String itemDescription, DonationType item) {
		super();
		this.itemId = itemId;
		this.itemDescription = itemDescription;
		this.item = item;
	}

	/**
	 * Gets the item id.
	 *
	 * @return the item id
	 */
	public int getItemId() {
		return itemId;
	}

	/**
	 * Sets the item id.
	 *
	 * @param itemId the new item id
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	/**
	 * Gets the item description.
	 *
	 * @return the item description
	 */
	public String getItemDescription() {
		return itemDescription;
	}

	/**
	 * Sets the item description.
	 *
	 * @param itemDescription the new item description
	 */
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	/**
	 * Gets the item.
	 *
	 * @return the item
	 */
	public DonationType getItem() {
		return item;
	}

	/**
	 * Sets the item.
	 *
	 * @param item the new item
	 */
	public void setItem(DonationType item) {
		this.item = item;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "DonationItem [itemId=" + itemId + ", itemDescription=" + itemDescription + ", item=" + item + "]";
	}

}