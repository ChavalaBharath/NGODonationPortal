package com.ngodonationportal.entity;

/**
 * The Enum DonationDistributionStatus.
 */
public enum DonationDistributionStatus {
	
	/** The pending. */
	PENDING, 
 /** The approved. */
 APPROVED, 
 /** The rejected. */
 REJECTED;

}
