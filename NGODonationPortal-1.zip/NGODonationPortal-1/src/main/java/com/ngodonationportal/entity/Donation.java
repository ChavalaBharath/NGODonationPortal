package com.ngodonationportal.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * The Class Donation.
 */
@Entity
@Table(name = "Donation")
public class Donation {

	/** The donation id. */
	@Id
	@GeneratedValue
	@Column(name = "donation_Id", length = 10)
	private int donationId;

	/** The donor. */
	@OneToOne
	@JoinColumn(name = "donors")
	private Donor donor;

	/** The donation amount. */
	private double donationAmount;

	/** The donation date. */
	private Date donationDate;

	/** The item. */
	@OneToOne
	@JoinColumn(name = "donationItem")
	private DonationItem item;

	/**
	 * Instantiates a new donation.
	 */
	public Donation() {
		super();
	}

	/**
	 * Instantiates a new donation.
	 *
	 * @param donationId     the donation id
	 * @param donor          the donor
	 * @param donationAmount the donation amount
	 * @param donationDate   the donation date
	 * @param item           the item
	 */
	public Donation(int donationId, Donor donor, double donationAmount, Date donationDate, DonationItem item) {
		super();
		this.donationId = donationId;
		this.donor = donor;
		this.donationAmount = donationAmount;
		this.donationDate = donationDate;
		this.item = item;
	}

	/**
	 * Gets the donation id.
	 *
	 * @return the donation id
	 */
	public int getDonationId() {
		return donationId;
	}

	/**
	 * Sets the donation id.
	 *
	 * @param donationId the new donation id
	 */
	public void setDonationId(int donationId) {
		this.donationId = donationId;
	}

	/**
	 * Gets the donor.
	 *
	 * @return the donor
	 */
	public Donor getDonor() {
		return donor;
	}

	/**
	 * Sets the donor.
	 *
	 * @param donor the new donor
	 */
	public void setDonor(Donor donor) {
		this.donor = donor;
	}

	/**
	 * Gets the donation amount.
	 *
	 * @return the donation amount
	 */
	public double getDonationAmount() {
		return donationAmount;
	}

	/**
	 * Sets the donation amount.
	 *
	 * @param donationAmount the new donation amount
	 */
	public void setDonationAmount(double donationAmount) {
		this.donationAmount = donationAmount;
	}

	/**
	 * Gets the donation date.
	 *
	 * @return the donation date
	 */
	public Date getDonationDate() {
		return donationDate;
	}

	/**
	 * Sets the donation date.
	 *
	 * @param donationDate the new donation date
	 */
	public void setDonationDate(Date donationDate) {
		this.donationDate = donationDate;
	}

	/**
	 * Gets the item.
	 *
	 * @return the item
	 */
	public DonationItem getItem() {
		return item;
	}

	/**
	 * Sets the item.
	 *
	 * @param item the new item
	 */
	public void setItem(DonationItem item) {
		this.item = item;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Donation [donationId=" + donationId + ", donor=" + donor + ", donationAmount=" + donationAmount
				+ ", donationDate=" + donationDate + ", item=" + item + "]";
	}

}