package com.ngodonationportal.service;

import java.util.Optional;

import com.ngodonationportal.entity.Donation;
import com.ngodonationportal.entity.Donor;

/**
 * The Interface DonorService.
 */
public interface DonorService {

	/**
	 * Register donor.
	 *
	 * @param donor the donor
	 * @return the donor
	 */
	public Donor registerDonor(Donor donor);

	/**
	 * Login.
	 *
	 * @param donorUsername the donor username
	 * @param donorPassword the donor password
	 * @return the donor
	 */
	public Donor login(String donorUsername, String donorPassword);

	/**
	 * Donate to NGO.
	 *
	 * @param donation the donation
	 * @return the donation
	 */
	public Donation donateToNGO(Donation donation);

	/**
	 * Send thankyou mail to donator.
	 *
	 * @param donor the donor
	 * @return the string
	 */
	public String sendThankyouMailToDonator(Donor donor);

	/**
	 * Reset password.
	 *
	 * @param donorId     the donor id
	 * @param oldPassword the old password
	 * @param newPassword the new password
	 * @return the string
	 */
	public String resetPassword(int donorId, String oldPassword, String newPassword);

	/**
	 * Email password to donor.
	 *
	 * @param donorEmail the donor email
	 * @return the string
	 */
	public String emailPasswordToDonor(String donorEmail);

	/**
	 * Forgot password.
	 *
	 * @param donorId the donor id
	 * @return the string
	 */
	public String forgotPassword(int donorId);

	/**
	 * Find donor by id.
	 *
	 * @param donorId the donor id
	 * @return the optional
	 */
	public Optional<Donor> findDonorById(int donorId);
}
