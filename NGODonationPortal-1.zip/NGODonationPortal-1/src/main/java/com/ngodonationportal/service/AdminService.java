package com.ngodonationportal.service;

import java.util.List;
import java.util.Optional;

import com.ngodonationportal.entity.Employee;

/**
 * The Interface AdminService.
 */
public interface AdminService {

	/**
	 * Adds the employee.
	 *
	 * @param employee the employee
	 * @return the employee
	 */
	public Employee addEmployee(Employee employee);

	/**
	 * Modify employee.
	 *
	 * @param employee the employee
	 * @return the employee
	 */
	public Employee modifyEmployee(Employee employee);

	/**
	 * Removes the employee.
	 *
	 * @param employeeId the employee id
	 * @return the string
	 */
	public String removeEmployee(int employeeId);

	/**
	 * Find employee by id.
	 *
	 * @param empId the emp id
	 * @return the optional
	 */
	public Optional<Employee> findEmployeeById(int empId);

	/**
	 * Find all employees.
	 *
	 * @return the list
	 */
	public List<Employee> findAllEmployees();

}
