package com.ngodonationportal.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ngodonationportal.dao.DonationDao;
import com.ngodonationportal.dao.DonorDao;
import com.ngodonationportal.entity.Donation;
import com.ngodonationportal.entity.Donor;

/**
 * The Class DonorServiceImpl.
 */
@Service
@Transactional
public class DonorServiceImpl implements DonorService {

	/** The dao. */
	@Autowired
	DonorDao dao;

	/** The dao 1. */
	@Autowired
	DonationDao dao1;

	/**
	 * Register donor.
	 *
	 * @param donor the donor
	 * @return the donor
	 */
	@Override
	public Donor registerDonor(Donor donor) {
		return dao.save(donor);
	}

	/**
	 * Donate to NGO.
	 *
	 * @param donation the donation
	 * @return the donation
	 */
	@Override
	public Donation donateToNGO(Donation donation) {

		return dao1.save(donation);
	}

	/**
	 * Send thankyou mail to donator.
	 *
	 * @param donor the donor
	 * @return the string
	 */
	@Override
	public String sendThankyouMailToDonator(Donor donor) {

		return "Thank you for Donation";
	}

	/**
	 * Forgot password.
	 *
	 * @param donorId the donor id
	 * @return the string
	 */
	@Override
	public String forgotPassword(int donorId) {
		Donor donor1 = dao.findById(donorId).get();
		return donor1.getDonorPassword();
	}

	/**
	 * Reset password.
	 *
	 * @param donorId     the donor id
	 * @param oldPassword the old password
	 * @param newPassword the new password
	 * @return the string
	 */
	@Override
	public String resetPassword(int donorId, String oldPassword, String newPassword) {
		Donor donor1 = dao.findById(donorId).get();
		if (donor1.getDonorPassword().equalsIgnoreCase(oldPassword)) {
			donor1.setDonorPassword(newPassword);
			donor1 = dao.save(donor1);
			return donor1.getDonorPassword();
		}
		return "Wrong Password";
	}

	/**
	 * Email password to donor.
	 *
	 * @param donorEmail the donor email
	 * @return the string
	 */
	@Override
	public String emailPasswordToDonor(String donorEmail) {

		return dao.findByDonorEmail(donorEmail).getDonorPassword();
	}

	/**
	 * Login.
	 *
	 * @param donorUsername the donor username
	 * @param donorPassword the donor password
	 * @return the donor
	 */
	@Override
	public Donor login(String donorUsername, String donorPassword) {

		return dao.findByDonorUsernameAndPassword(donorUsername, donorPassword);

	}

	/**
	 * Find donor by id.
	 *
	 * @param donorId the donor id
	 * @return the optional
	 */
	@Override
	public Optional<Donor> findDonorById(int donorId) {

		return dao.findById(donorId);
	}
}
