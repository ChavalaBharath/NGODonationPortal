package com.ngodonationportal.service;

import java.util.List;
import java.util.Optional;

import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.entity.NeedyPeople;

/**
 * The Interface EmployeeService.
 */
public interface EmployeeService {

	/**
	 * Login.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the employee
	 */
	Employee login(String username, String password);

	/**
	 * Adds the needy person.
	 *
	 * @param person the person
	 * @return the needy people
	 */
	NeedyPeople addNeedyPerson(NeedyPeople person);

	/**
	 * Removes the needy person.
	 *
	 * @param needyPersonId the needy person id
	 * @return the string
	 */
	String removeNeedyPerson(int needyPersonId);

	/**
	 * Find needy people by id.
	 *
	 * @param needyPersonId the needy person id
	 * @return the optional
	 */
	Optional<NeedyPeople> findNeedyPeopleById(int needyPersonId);

	/**
	 * Find needy people by name.
	 *
	 * @param name the name
	 * @return the optional
	 */
	Optional<NeedyPeople> findNeedyPeopleByName(String name);

	/**
	 * Find all needy people.
	 *
	 * @return the list
	 */
	List<NeedyPeople> findAllNeedyPeople();

}
