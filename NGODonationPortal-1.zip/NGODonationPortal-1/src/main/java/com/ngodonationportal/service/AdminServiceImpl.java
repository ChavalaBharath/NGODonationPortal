package com.ngodonationportal.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ngodonationportal.dao.AdminDao;
import com.ngodonationportal.entity.Employee;

/**
 * The Class AdminServiceImpl.
 */
@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	/** The dao. */
	@Autowired
	AdminDao dao;

	/**
	 * Adds the employee.
	 *
	 * @param employee the employee
	 * @return the employee
	 */
	@Override
	public Employee addEmployee(Employee employee) {

		return dao.save(employee);
	}

	/**
	 * Modify employee.
	 *
	 * @param employee the employee
	 * @return the employee
	 */
	@Override
	public Employee modifyEmployee(Employee employee) {

		return dao.save(employee);
	}

	/**
	 * Removes the employee.
	 *
	 * @param employeeId the employee id
	 * @return the string
	 */
	@Override
	public String removeEmployee(int employeeId) {

		dao.deleteById(employeeId);
		return "employee deleted sucessfully";
	}

	/**
	 * Find employee by id.
	 *
	 * @param empId the emp id
	 * @return the optional
	 */
	@Override
	public Optional<Employee> findEmployeeById(int empId) {

		return dao.findById(empId);
	}

	/**
	 * Find all employees.
	 *
	 * @return the list
	 */
	@Override
	public List<Employee> findAllEmployees() {

		return dao.findAll();
	}

}