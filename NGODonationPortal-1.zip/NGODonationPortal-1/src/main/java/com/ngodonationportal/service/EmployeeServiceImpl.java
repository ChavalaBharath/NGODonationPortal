package com.ngodonationportal.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ngodonationportal.dao.EmployeeDao;
import com.ngodonationportal.dao.NeedyPeopleDao;
import com.ngodonationportal.entity.Employee;
import com.ngodonationportal.entity.NeedyPeople;

/**
 * The Class EmployeeServiceImpl.
 */
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	/** The dao. */
	@Autowired
	NeedyPeopleDao dao;

	/** The dao 1. */
	@Autowired
	EmployeeDao dao1;

	/**
	 * Login.
	 *
	 * @param username the username
	 * @param password the password
	 * @return the employee
	 */
	@Override
	public Employee login(String username, String password) {
		return dao1.findByUsernameAndPassword(username, password);
	}

	/**
	 * Adds the needy person.
	 *
	 * @param person the person
	 * @return the needy people
	 */
	@Override
	public NeedyPeople addNeedyPerson(NeedyPeople person) {
		return dao.save(person);
	}

	/**
	 * Removes the needy person.
	 *
	 * @param needyPersonId the needy person id
	 * @return the string
	 */
	@Override
	public String removeNeedyPerson(int needyPersonId) {
		dao.deleteById(needyPersonId);
		return "Deleted Successfully";
	}

	/**
	 * Find needy people by id.
	 *
	 * @param needyPersonId the needy person id
	 * @return the optional
	 */
	@Override
	public Optional<NeedyPeople> findNeedyPeopleById(int needyPersonId) {
		return dao.findById(needyPersonId);
	}

	/**
	 * Find needy people by name.
	 *
	 * @param name the name
	 * @return the optional
	 */
	@Override
	public Optional<NeedyPeople> findNeedyPeopleByName(String name) {
		return dao.findByNeedyPeopleName(name);
	}

	/**
	 * Find all needy people.
	 *
	 * @return the list
	 */
	@Override
	public List<NeedyPeople> findAllNeedyPeople() {
		return dao.findAll();
	}

}
